<?php

/**
 * Auth Controller
 * This controller does all user management.
 *
 * @package Auth
 * @author Henry Nkuke
 * @link http://waldir.org/
 **/
class Auth extends MX_Controller {
	
	function __construct(){
		parent::__construct();
		$this->module="auth";
	}

	function notFound(){

			echo "<h1> Page not Found </h2>";
	}
	
	function index()
	{
		// If user is already logged in, send it to private page
		$this->user->on_valid_session('dashboard');
		// Loads the login view
		$data['view']='login';
		$data['module']=$this->module;
		echo Modules::run('templates/plain',$data);
	}
	
	function private_page(){
		// if user tries to direct access it will be sent to login
		$this->user->on_invalid_session('login');
		// ... else he will view home
		redirect('dashboard');
	}
	
	function validate()
	{
		// Receives the login data
		$login = $this->input->post('login');
		$password = $this->input->post('credential');
		/* 
		 * Validates the user input
		 * The user->login returns true on success or false on fail.
		 * It also creates the user session.
		*/
		if($this->user->login($login, $password)){
			// Success
			redirect('dashboard');
		} else {
			$msg = "<font color='red'>Invalid login credentials</font>";
			Modules::run('utility/setFlash',$msg);
			// Oh, holdon sir.
			redirect('auth');
		}
	}
	
	// Simple logout function
	function logout()
	{
		// Removes user session and redirects to login
		$this->user->destroy_user('auth');
	}

	function initialPermissions(){

		$permission_id = $this->user_manager->save_permission('edit', 'Manages data &makes changes');
		$permission_id = $this->user_manager->save_permission('create', 'Creates new data');
		$permission_id = $this->user_manager->save_permission('delete', 'Can delete Entries');
		$permission_id = $this->user_manager->save_permission('edit_loan', 'Modifies loan Entries');
		$permission_id = $this->user_manager->save_permission('edit_customer', 'Modifies loan Entrie');
		$permission_id = $this->user_manager->save_permission('view_loans', 'Sees loan Entries');
	}

	public function deleteUser(){
	  if($this->user_manager->delete_user($user_id)){
	  echo "User was deleted.";
     }
   }
}
?>
