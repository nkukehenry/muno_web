    <!-- Pre-loader start -->
    <!--<div class="theme-loader">
        <div class="ball-scale">
            <div></div>
        </div>
    </div>-->
    <!-- Pre-loader end -->
<?php include('theme_header.php'); ?>
<?php include('main_menu.php'); ?>

