		
		<div class="clearFix"></div>
		<div class="contentBody w500">
			<div class="contentTitle">{{content title}}</div>
			<div class="clearFix"></div>
			<div class="midcontentBody">test</div>
		</div>
