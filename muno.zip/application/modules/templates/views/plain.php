<?php
include('includes/css_files.php');
 $this->load->view($module.'/'.$view); 
include('includes/footer.php');
  ?>
