<?php

$config['redis_slave']['host'] = '10.1.5.3';		// IP address or host
$config['redis_slave']['port'] = '6379';			// Default Redis port is 6379
$config['redis_slave']['password'] = '';			// Can be left empty when the server does not require AUTH


?>