<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rooms_mdl extends CI_Model {

	public function __construct(){

		parent::__construct();

		$this->db_table="room_tb";


	}

	
	

	public function getAll()
	{
		$query=$this->db->get($this->db_table);

		return $query->result();
		
	}


	public function getById($roomId)
	{
		$this->db->where("room_id",$roomId);
		$query=$this->db->get($this->db_table);

		return $query->row();
		
	}




}
