<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends MX_Controller {



	public function __construct(){

		parent::__construct();

		//header("Access-Control-Allow-Origin:*");

		Modules::run("schedules/mdlAccess"); //schedules model from schedules module

		$this->failure_image=file_get_contents(FCPATH."failed_image.txt");
		$this->success_image=file_get_contents(FCPATH."success_image.txt");

	}



public function saveData(){

header('Access-Control-Allow-Origin: *');
$target_path = FCPATH."assets/img/attendance_pics/";

$studentphoto_name = str_replace("/","",$this->input->post('regnumber')).date("Y-m-d").time().".jpg";
 
$target_path = $target_path.$studentphoto_name; //path to store photo

$course_code=$this->input->post('course_code');
$stud_reg=$this->input->post('regnumber');
$formatted_reg=str_replace("/", "_",$stud_reg);

$course=$this->checkCourse($course_code);//check for course using course code
$student=$this->checkStudent($formatted_reg);//check for student using reg number


if(count($course)<1 or count($student)<1){

//if no course or student matches the submitted data
	$response=$this->failure_image;
}

else{

// course and student matches found for submitted data
$course_programid=$course->program_id;
$course_class=$course->class_id;

$student_programid=$student->program_id;
$student_class=$student->class_id;

//if courses and programs match
if($student_programid==$course_programid && $student_class==$course_class){


$course_id=$course->course_id;//id for the course to attend

$schedule=$this->toAttend($course_id); // scheduled lecture to attend

$schedule_id=$schedule->schedule_id;

$attendanceData=array(
"student_regnumber"=>$stud_reg,
"student_photo"=>$studentphoto_name,
"schedule_id"=>$schedule_id
);

$done=$this->confirmAttendance($attendanceData);

if($done=="success"){  // if confirm attendance succeeds

	if (move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {
    
    $response=$this->success_image;
}
}

else{

//confirm attendance failed
$response=$this->failure_image;

}


}//if courses and programs match

else{
//submitted data exits but not matching stud class and program
$response=$this->failure_image;
}

}//else for course and student existence/found

echo $response ;
}




 
	public function checkCourse($course_code){
		Modules::run("courses/mdlAccess");//load courses model

		$course=$this->courses_mdl->apiCourse($course_code);

		return $course;

		//print_r($course);

	}


	public function checkStudent($formatted_reg){

    Modules::run("students/mdlAccess");//load courses model
    $student=$this->students_mdl->apiStudent($formatted_reg);

    return $student;

    //print_r($student);
		
	}


	public function confirmAttendance($attendanceData){

		$done=$this->db->insert("stdattendance",$attendanceData);
		//$this->db->affected_rows();

		if($done){

			return "success";
		}
		else{

			return "failure";
		}
	}


public function mySchedules($staffId){
		

		Modules::run("schedules/mdlAccess");//load schedules model

		$schedules=$this->schedules_mdl->getForLecturer($staffId);

	   echo json_encode($schedules);


	}


public function mySchedulesToday($staffId){
		

		Modules::run("schedules/mdlAccess");//load schedules model

		$schedules=$this->schedules_mdl->forLecturerToday($staffId);

	   echo json_encode($schedules);


	}


//initializing

	public function initLecture(){

 $json =  file_get_contents('php://input');
 $postdata=  json_decode($json);

  $schedule_id =filter_var($postdata->schedule_id, FILTER_SANITIZE_STRING, FILTER_FLAG_ENCODE_LOW);

     Modules::run("schedules/mdlAccess");

	$result=$this->schedules_mdl->initLecture($schedule_id);

	$msg=$result; 

	
	if($msg="Lecture has been Initialized successfully"){

		$status="ok";
	}
	else{
		$status="failed";
	}

	$response= array('message' =>$status);

	echo json_encode($response);
	}


	//ending lecture

	public function endLecture(){

 $json =  file_get_contents('php://input');
 $postdata=  json_decode($json);

  $schedule_id =filter_var($postdata->schedule_id, FILTER_SANITIZE_STRING, FILTER_FLAG_ENCODE_LOW);

    Modules::run("schedules/mdlAccess");
     
	$result=$this->schedules_mdl->endLecture($schedule_id);

	$msg=$result;//feedback from model

	if($msg="Lecture has been Closed off successfully"){

		$status="ok";
	}
	else{
		$status="failed";
	}

	$response= array('message' =>$status);

	echo json_encode($response);


	}


	public function toAttend($course_id){
 
     Modules::run("schedules/mdlAccess");

     $today=date("w");

	$schedule=$this->schedules_mdl->toAttend($course_id,$today);

	return $schedule;

	//print_r($schedule);

	}



public function fetchCourses(){

//header('Access-Control-Allow-Origin: *');

	 Modules::run("schedules/mdlAccess");


	 $weekdays=array(
    "1"=>"Monday",
    "2"=>"Tuesday",
    "3"=>"Wednesday",
    "4"=>"Thursday",
    "5"=>"Friday",
    "6"=>"Saturday",
    "0"=>"Sunday"
);

	$schedules=array();

 	//$results=$this->schedules_mdl->forLecturerToday($userid);

$results=$this->schedules_mdl->getAll();
	 foreach ($results as $result) {
	 	
		$course_name = $result->course_name;
	 	$day = $weekdays[$result->day];
	 	$course_code = $result->course_code;

	 	$rowdata=array(
	 		"course"=>$course_name,
	 		"code"=>$course_code,
	 		"day"=>$day,
	 		"time"=>date("h:i",strtotime($result->start_time))."-".date("h:i",strtotime($result->end_time))
	 	);

	 	array_push($schedules,$rowdata); 
	 }


	 	echo json_encode($schedules);


}


public function fetchTodaysCourses(){


	 Modules::run("schedules/mdlAccess");

	 $weekdays=array(
    "1"=>"Monday",
    "2"=>"Tuesday",
    "3"=>"Wednesday",
    "4"=>"Thursday",
    "5"=>"Friday",
    "6"=>"Saturday",
    "0"=>"Sunday"
);

	$schedules=array();

$results=$this->schedules_mdl->forLecturerToday(1);

//$results=$this->schedules_mdl->getAll();

    $today=date("w");

	$todaysdate=date("Y-m-d");


	 foreach ($results as $result) {
	 	
	 	$last_date=$result->last_date;
		$course_name = $result->course_name;
	 	$day = $weekdays[$result->day];//day inwords representing day number in db
	 	$course_code = $result->course_code;
	 	$state = $result->state;

	 	$dayno=$result->day;//number for day from db

	 	$newstate="";
 if($dayno==$today && $last_date==date("Y-m-d") && $state=="Initialized"){

	 		$newstate="end"; // tell app that weed to show the init button

	 	} 


	 	else if($dayno==$today && $last_date!==date("Y-m-d") && $state!=="Initialized"){

	 		$newstate="init"; // tell app that weed to show the end button
	 	}

	 	$rowdata=array(
	 		"course"=>$course_name,
	 		"schedule_id"=>$result->schedule_id,
	 		"code"=>$course_code,
	 		"day"=>$day,
	 		"dayno"=>$dayno,
	 		"today"=>$today,
	 		'state'=>$newstate,
	 		"todaysdate"=>$todaysdate,
	 		"lastdate"=>$result->last_date,
	 		"time"=>date("h:i",strtotime($result->start_time))."-".date("h:i",strtotime($result->end_time))
	 	);

	 	array_push($schedules,$rowdata); 
	 }


	 	echo json_encode($schedules);


}


public function login(){
	
 $json =  file_get_contents('php://input');
 $credentials=  json_decode($json);

    $username = filter_var($credentials->username, FILTER_SANITIZE_STRING, FILTER_FLAG_ENCODE_LOW);
    $password = filter_var($credentials->password, FILTER_SANITIZE_STRING, FILTER_FLAG_ENCODE_LOW);

		
		 $logindata = array('username' =>$username ,'password'=>$password );

		 $response = $this->auth_mdl->apiLogin($logindata);

		 echo json_encode($response);
	}

}
