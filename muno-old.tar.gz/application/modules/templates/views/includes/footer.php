 
    <!-- Core JS files -->
    <script src="<?php echo BASE_URL; ?>assets/main/jquery.min.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/main/bootstrap.bundle.min.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/blockui.min.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/ripple.min.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/fab.min.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/select2.min.js"></script>
    <!-- /core JS files -->
    <!-- Theme JS files -->
    <script src="<?php echo BASE_URL; ?>assets/js/app.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/custom.js"></script>
    <!-- /theme JS files -->
   
  </body>
</html>