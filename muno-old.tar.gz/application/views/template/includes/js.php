    
    <script type="text/javascript" src="<?php echo BOWER; ?>tether/dist/js/tether.min.js"></script>
    <script type="text/javascript" src="<?php echo BOWER; ?>bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- jquery slimscroll js -->
    <script type="text/javascript" src="<?php echo BOWER; ?>jquery-slimscroll/jquery.slimscroll.js"></script>
    <!-- modernizr js -->
    <script type="text/javascript" src="<?php echo BOWER; ?>modernizr/modernizr.js"></script>
    <script type="text/javascript" src="<?php echo BOWER; ?>modernizr/feature-detects/css-scrollbars.js"></script>
    <!-- classie js -->
    <script type="text/javascript" src="<?php echo BOWER; ?>classie/classie.js"></script>
    <!-- i18next.min.js -->
    <script type="text/javascript" src="<?php echo BOWER; ?>i18next/i18next.min.js"></script>
    <script type="text/javascript" src="<?php echo BOWER; ?>i18next-xhr-backend/i18nextXHRBackend.min.js"></script>
    <script type="text/javascript" src="<?php echo BOWER; ?>i18next-browser-languagedetector/i18nextBrowserLanguageDetector.min.js"></script>
    <script type="text/javascript" src="<?php echo BOWER; ?>jquery-i18next/jquery-i18next.min.js"></script>
    <!-- Custom js -->
    <script type="text/javascript" src="<?php echo ASSET_URL; ?>js/script.js"></script>