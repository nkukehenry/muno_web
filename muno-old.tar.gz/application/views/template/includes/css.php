 <!-- Favicon icon -->
    <link rel="icon" href="<?php echo IMG_URL; ?>favicon.ico" type="image/x-icon">
    <!-- Google font-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="<?php echo BOWER; ?>bootstrap/dist/css/bootstrap.min.css">
    <!-- themify-icons line icon -->
    <link rel="stylesheet" type="text/css" href="<?php echo ICON_URL; ?>themify-icons/themify-icons.css">    
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="<?php echo ICON_URL; ?>icofont/css/icofont.css">
    <!-- flag icon framework css -->
    <link rel="stylesheet" type="text/css" href="<?php echo PAGE_URL; ?>flag-icon/flag-icon.min.css">
  
    <!-- Style.css -->
     <link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>style.css">
    <!--color css-->
    <link rel="stylesheet" type="text/css" href="<?php echo CSS_URL; ?>color/color-1.css" id="color"/>

  <script type="text/javascript" src="<?php echo BOWER; ?>jquery/dist/jquery.min.js"></script>
   <!-- <script type="text/javascript" src="<?php echo BOWER; ?>jquery-ui/jquery-ui.min.js"></script>-->
<script type="text/javascript" src="<?php echo JS_URL; ?>jquery-3.4.1.min.js"></script>


    <?php include('old_js.php'); //from version 1 ?>
